# Satoshi Nakamotos Auth0 Blackbox
- Author Johnathan Edward Brown
- This allows you to run a Auth0 Server in runetime as simple as setting up a public folder in your node module and importing auth0-blackbox
- after importing the class object Container from it! You can use Container class to run the public website code through a auth0 container server that is Triple encapsulated using classes and with 2 layers of obfuscation.
- Tutorials will be included on using here soon....


# The purpose of this
- This is to help auth0 servers have extra redudant layers of security to properly hold session data in a secure manner as production developers would do!
- This is to help speedline developers in the future on needing to make obfuscation classes with extra layers thanks to the Babel family for the npm module for having useful custom obfuscation setups along with the Javascript-obfuscator for making this project possible along With NodeJS, Auth0!!!
- Please use this software in a legal and responsible way you have been warned, I am not liable for any misuse of this software and design. You are and your choices matter....


# History Story
- Long time ago when bitcoin was being developed me and senior developer Redacted(May Be revealed one day! Upto them...) we will call them! Came up with a fun experiment on making a obfuscated environment setup which could securely hold a Web server which may have exploits in it in a secure manner and prevent exploits from being usable due to the rotating nature design of the obfuscation!
- We discovered a very unique phenomena utilizing private classes 3 way setup! One to obfuscate the obfuscator! We found we could have the rotating obfuscation code obfuscated and ran in VM context. Then from there spawn another encapsulated VM Environment. What this did was create a 2 layer encapsulation with 2 layers of obfuscation for security and I made it all without costing a whole lot of resources.. So today i've remebered said experiment we did and plan to recreate for usage with Auth0 Servers to Help the world protect these Auth servers they may have!

# Issues I Predicted
- Due To growing AI pentesting tools I Fear utilizing for Auth0 Server and needing a 5 minute window open could pose a threat! but 5 minute window is to allow graceful user Sessions!
- Obfuscations Are not always perfect. Problems sometimes happen with server Runetime but suprisingly the percentages of this happening where very slim, Actually never had an issue like I theorized!



# Credits
- Murphy's Law
- Snake eating itself
- CHAT-GPT-4.0 for boiler design with babel for vm setups!